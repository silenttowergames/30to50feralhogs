function img(src){
	return document.querySelector(`img[src="${src}"]`);
}